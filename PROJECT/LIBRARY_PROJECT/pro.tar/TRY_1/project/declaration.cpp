#define MAX 40

int mainMenu();


