#include"class.cpp"
#include"header.cpp"
#include"declaration.cpp"


void Library::checkInBook()
{
	ofstream b_ofile("books.dat",ios::app);
	this->b.status=1;
	cout<<"enter author_name(aName):";
	cin>>	
	
	
	
}


#ifdef 0
 typedef struct
        {
                int status;// 0 :out, 1 :in.
                string aName;//authors name
                int year;// year(date) of release
                string bName[MAX];//book name
                string palce[MAX];// place of publish/release
                string pHouse[MAX];//publishing house           
        }book;
#endif

