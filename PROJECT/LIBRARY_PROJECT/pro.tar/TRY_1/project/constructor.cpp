#include"class.cpp"
#include"header.cpp"

Library::Library()
{

	book bb;
		bb.status=1;
		bb.aName="shivam rawat";
		bb.year="13 dec 2013";
		bb.bName="bookname__name";
		bb.place="pub_lishing__PLACE";
		bb.pHouse="pub_HOUSE";
		

		b.push_back(bb);


}





#ifdef 0
typedef struct
        {
                int status;// 0 :out, 1 :in.
                string aName;//authors name
                string year;// year(date) of release
                string bName[MAX];//book name
                string palce[MAX];// place of publish/release
                string pHouse[MAX];//publishing house           
        }book;
#endif








