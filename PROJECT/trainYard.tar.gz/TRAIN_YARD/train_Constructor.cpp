#include"headers.h"
#include"classes.h"

train::train()
{
#ifdef DEBUG
	cout<<"BEGIN: "<<__func__<<"\n";
#endif
	noOfCars=8;

#ifdef DEBUG
	cout<<"END: "<<__func__<<"\n";
#endif
}


